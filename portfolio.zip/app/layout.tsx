import type { Metadata, Viewport } from 'next'
import { Inter, JetBrains_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-inter',
})

const jetbrainsMono = JetBrains_Mono({ 
  subsets: ["latin"],
  variable: '--font-jetbrains-mono',
})

export const metadata: Metadata = {
  title: 'Umarr | Full Stack Developer & AI Engineer',
  description: 'Building the future with code. Full stack developer specializing in AI, modern web technologies, and creating exceptional digital experiences.',
  keywords: ['developer', 'full stack', 'AI', 'web development', 'React', 'Next.js', 'TypeScript'],
  authors: [{ name: 'Umarr' }],
  openGraph: {
    title: 'Umarr | Full Stack Developer & AI Engineer',
    description: 'Building the future with code. Full stack developer specializing in AI, modern web technologies, and creating exceptional digital experiences.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Umarr | Full Stack Developer & AI Engineer',
    description: 'Building the future with code.',
  },
}

export const viewport: Viewport = {
  themeColor: '#0d1117',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${jetbrainsMono.variable} bg-background`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
